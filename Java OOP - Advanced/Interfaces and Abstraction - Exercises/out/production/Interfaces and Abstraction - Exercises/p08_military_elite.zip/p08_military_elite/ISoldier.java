package p08_military_elite;

public interface ISoldier {
    int getId();
    String getFirstName();
    String getLastName();
}
