package p08_military_elite;

public interface IPrivate extends ISoldier {
    double getSalary();
}
