package p08_military_elite;

public interface ISpecialisedSoldier extends ISoldier{
    String getCorps();
}
