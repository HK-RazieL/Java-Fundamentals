package p08_military_elite;

public interface IEngineer extends ISpecialisedSoldier{
    void addRepairs(String part, int hours);
}
