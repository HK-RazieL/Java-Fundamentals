package p08_military_elite;

public interface ILeutenantGeneral extends ISoldier, IPrivate {
        void addPrivates(Private id);
}
