package p08_military_elite;

public interface ISpy extends ISoldier{
    int getCodeNumber();
}
